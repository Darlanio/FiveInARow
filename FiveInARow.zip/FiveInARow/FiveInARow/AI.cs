﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FiveInARow
{
    internal class AI
    {
        internal static void AIMakeMove(Rules r, int playernumber)
        {
            long bestscore = long.MinValue, score;
            Random rnd = new Random();
            List<Move> moves = new List<Move>();

            // Calculate for all empty positions within range of present pieces the threat for both sides
            r.UpdateBorders();
            for (long y = (r.minx - 4); y < (r.maxy + 5); y++)
            {
                for (long x = (r.minx - 4); x < (r.maxx + 5); x++)
                {
                    if (r.GetPlayer(x, y) == 0)
                    {
                        score = GetScore(r, x, y, playernumber);
                        if (bestscore <= score)
                        {
                            int rand = rnd.Next();
                            moves.Add(new Move() { x = x, y = y, score = score, rnd = rand });
                            bestscore = score;
                        }
                    }
                }
            }
            Move m = moves.Where(o => o.score == bestscore).OrderBy(o => o.rnd).First();
            r.pieces.Add(new Piece(m.x, m.y, playernumber));
        }

        //private static long GetScore(Rules r, long x, long y, int playernumber)
        //{
        //    int rv = 0; // Returnvalue for this position
        //    long[] dx = { 0, 1, 1, 1, 0, -1, -1, -1 }, dy = { -1, -1, 0, 1, 1, 1, 0, -1 };

        //    // Count eight directions for influence - this gives the preliminary score
        //    // Add bonus for directions where the counterdirection is not blocked at l=1 (open after move)
        //    // Sum up all directions that are not blocked

        //    int[] tmpscr1 = new int[8];
        //    int[] tmpscr2 = new int[8];
        //    int[] blocked1 = new int[8];
        //    int[] blocked2 = new int[8];

        //    // First we count the preliminary score for each player in each of the eight directions
        //    // We also note the distance to first piece for each player in each of the eight directions
        //    for (int d = 0; d < 8; d++)
        //    {
        //        tmpscr1[d] = 0;
        //        tmpscr2[d] = 0;
        //        blocked1[d] = 0;
        //        blocked2[d] = 0;
        //        for (int l = 1; l < 5; l++)
        //        {
        //            int presentPlayer = r.GetPlayer(x + dx[d] * l, y + dy[d] * l);
        //            if (presentPlayer != 0)
        //            {
        //                if (presentPlayer == 1)
        //                {
        //                    if (blocked2[d] == 0) tmpscr1[d] += (5 - l);
        //                    if (blocked1[d] == 0) blocked1[d] = l;
        //                }
        //                else
        //                {
        //                    if (blocked1[d] == 0) tmpscr2[d] += (5 - l);
        //                    if (blocked2[d] == 0) blocked2[d] = l;
        //                }
        //            }
        //        }
        //        if (blocked1[d] == 0) blocked1[d] = 5;
        //        if (blocked2[d] == 0) blocked2[d] = 5;
        //    }
        //    // Now we have all data and can sum this up into a score for the position
        //    for (int d = 0; d < 4; d++)
        //    {
        //        if (blocked2[d] + blocked2[d + 4] < 5)
        //        {
        //            tmpscr1[d] = 0;
        //            tmpscr1[d + 4] = 0;
        //        }
        //        if (blocked1[d] + blocked1[d + 4] < 5)
        //        {
        //            tmpscr2[d] = 0;
        //            tmpscr2[d + 4] = 0;
        //        }
        //        rv += 3 ^ (tmpscr1[d] + tmpscr1[d + 4]) + 3 ^ (tmpscr2[d] + tmpscr2[d + 4]);
        //        //rv += tmpscr1[d] + tmpscr1[d + 4] + tmpscr2[d] + tmpscr2[d + 4];
        //    }
        //    return rv;
        //}

        private static long GetScore(Rules r, long x, long y, int playernumber)
        {
            int rv = 0; // Returnvalue for this position
            long[] dx = { 0, 1, 1, 1, 0, -1, -1, -1 }, dy = { -1, -1, 0, 1, 1, 1, 0, -1 };
            int[] eval = { 0, 29, 17, 7, 2 };

            int[] distance1 = new int[8];
            int[] distance2 = new int[8];

            int[] tmpscr1 = new int[8];
            int[] tmpscr2 = new int[8];

            for (int d = 0; d < 8; d++)
            {
                distance1[d] = 6;
                distance2[d] = 6;
                tmpscr1[d] = 0;
                tmpscr2[d] = 0;
                for (int l = 4; l > 0; l--)
                {
                    switch (r.GetPlayer(x + dx[d] * l, y + dy[d] * l))
                    {
                        case 2:
                            distance2[d] = l;
                            tmpscr2[d] += eval[l];
                            tmpscr1[d] = 0;
                            break;
                        case 1:    
                            distance1[d] = l;
                            tmpscr1[d] += eval[l];
                            tmpscr2[d] = 0;
                            break;
                        case 0:
                        default:
                            tmpscr1[d]++;
                            tmpscr2[d]++;
                            break;
                    }
                }
            }
            // Count score in each pair of the directions (4 diffrent pairs)
            for (int d = 0; d < 4; d++)
            {
                int p1, p2;

                p1 = tmpscr1[d] + tmpscr1[d + 4];
                p2 = tmpscr2[d] + tmpscr2[d + 4];

                if ((distance1[d] + distance1[d + 4]) < 5) p2 = 0;
                if ((distance2[d] + distance2[d + 4]) < 5) p1 = 0;

                p1 = ApplyScoreModifications(tmpscr1, d, eval, p1);
                p2 = ApplyScoreModifications(tmpscr2, d, eval, p2);

                if (p1 > p2)
                {
                    rv += p1;
                }
                else
                {
                    rv += p2;
                }
            }
            return rv;
        }

        private static int ApplyScoreModifications(int[] tmpscr, int d, int[] eval, int p)
        {
            // 1 + tomt + 3 eller 3 + tomt + 1
            if (tmpscr[d] >= eval[1] && tmpscr[d + 4] >= eval[1] + eval[2] + eval[3])
            {
                p += 10000;
            }
            if (tmpscr[d + 4] >= eval[1] && tmpscr[d] >= eval[1] + eval[2] + eval[3])
            {
                p += 10000;
            }
            if (tmpscr[d] >= eval[1] +eval[2] && tmpscr[d+4] >= eval[1] + eval[2])
            {
                p += 10000;
            }
            // Four in a row without stop in at least one direction (the empty square being analyzed)
            if (tmpscr[d] >= eval[1] + eval[2] + eval[3] + eval[4] || tmpscr[d + 4] >= eval[1] + eval[2] + eval[3] + eval[4])
            {
                p += 10000;
            }
            // Three in a row without stop in both directions (will give four in a row without stop in at least one direction)
            if (tmpscr[d] >= eval[1] + eval[2] + eval[3] + 1 || tmpscr[d+4] >= eval[1] + eval[2] + eval[3] + 1)
            {
                p += 1000;
            }
            return p;
        }

        //private static long GetScore(Rules r, long x, long y, int playernumber)
        //{
        //    int rv = 0; // Returnvalue for this position
        //    long[] dx = { 0, 1, 1, 1, 0, -1, -1, -1 }, dy = { -1, -1, 0, 1, 1, 1, 0, -1 };

        //    int[] distance1 = new int[8];
        //    int[] distance2 = new int[8];

        //    int[] tmpscr1 = new int[8];
        //    int[] tmpscr2 = new int[8];

        //    for (int d = 0; d < 8; d++)
        //    {
        //        distance1[d] = 6;
        //        distance2[d] = 6;
        //        tmpscr1[d] = 0;
        //        tmpscr2[d] = 0;
        //        for (int l = 5; l > 0; l--)
        //        {
        //            switch (r.GetPlayer(x + dx[d]*l, y + dy[d]*l))
        //            {
        //                case 2:
        //                    distance2[d] = l;
        //                    tmpscr2[d] += 6-l;
        //                    tmpscr1[d] = 0;
        //                    break;
        //                case 1:
        //                    distance1[d] = l;
        //                    tmpscr1[d] += 6-l;
        //                    tmpscr2[d] = 0;
        //                    break;
        //                case 0:
        //                default:
        //                    tmpscr1[d]++;
        //                    tmpscr2[d]++;
        //                    break;
        //            }
        //        }
        //    }
        //    // Count score in each pair of the directions (4 diffrent pairs)
        //    for (int d = 0; d < 4; d++)
        //    {
        //        int p1, p2;

        //        p1 = tmpscr1[d] + tmpscr1[d + 4];
        //        p2 = tmpscr2[d] + tmpscr2[d + 4];
        //        if ((distance1[d] + distance1[d + 4]) < 5) p2 = 0;
        //        if ((distance2[d] + distance2[d + 4]) < 5) p1 = 0;
        //        if (p1 > p2)
        //        {
        //            rv += p1;
        //        }
        //        else
        //        {
        //            rv += p2;
        //        }
        //    }            
        //    return rv;
        //}



            //// First we count the preliminary score for each player in each of the eight directions
            //// We also note the distance to first piece for each player in each of the eight directions
            //int[] blocked1 = new int[8];
            //int[] blocked2 = new int[8];
            //for (int d = 0; d < 8; d++)
            //{
            //    tmpscr1[d] = 0;
            //    tmpscr2[d] = 0;
            //    blocked1[d] = 0;
            //    blocked2[d] = 0;
            //    for (int l = 1; l < 5; l++)
            //    {
            //        int presentPlayer = r.GetPlayer(x + dx[d] * l, y + dy[d] * l);
            //        if (presentPlayer != 0)
            //        {
            //            if (presentPlayer == 1)
            //            {
            //                if (blocked2[d] == 0) tmpscr1[d]++; //+= (6 - l);
            //                if (blocked1[d] == 0) blocked1[d] = l;
            //            }
            //            else
            //            {
            //                if (blocked1[d] == 0) tmpscr2[d]++; //+= (6 - l);
            //                if (blocked2[d] == 0) blocked2[d] = l;
            //            }
            //        }
            //    }
            //    if (blocked1[d] == 0) blocked1[d] = 5;
            //    if (blocked2[d] == 0) blocked2[d] = 5;
            //}
            //// Now we have all data and can sum this up into a score for the position
            //for (int d = 0; d < 4; d++)
            //{
            //    if (blocked2[d] + blocked2[d + 4] < 5)
            //    {
            //        tmpscr1[d] = 0;
            //        tmpscr1[d + 4] = 0;
            //    }
            //    if (blocked1[d] + blocked1[d + 4] < 5)
            //    {
            //        tmpscr2[d] = 0;
            //        tmpscr2[d + 4] = 0;
            //    }
            //    rv += 3 ^ (tmpscr1[d] + tmpscr1[d + 4]) + 3 ^ (tmpscr2[d] + tmpscr2[d + 4]);
            //    //rv += tmpscr1[d] + tmpscr1[d + 4] + tmpscr2[d] + tmpscr2[d + 4];
            //}
        //    return rv;
        //}

    }
}
