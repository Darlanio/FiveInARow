﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FiveInARow
{
    internal class Rules
    {
        internal long minx = long.MaxValue, miny = long.MaxValue, maxx = long.MinValue, maxy = long.MinValue;
        internal List<Piece> pieces = new List<Piece>();
        internal int tomove = 1;
        internal Random rnd = new Random();

        internal void UpdateBorders()
        {
            minx = long.MaxValue;
            miny = long.MaxValue;
            maxx = long.MinValue;
            maxy = long.MinValue;
            foreach (Piece p in pieces)
            {
                if (p.x < minx) minx = p.x;
                if (p.y < miny) miny = p.y;
                if (p.x > maxx) maxx = p.x;
                if (p.y > maxy) maxy = p.y;
            }
        }

        //private static void DisplayBoard()
        //{
        //    UpdateBorders();

        //    for (long y = miny - 4; y < maxy + 5; y++)
        //    {
        //        for (long x = minx - 4; x < maxx + 5; x++)
        //        {
        //            switch (GetPlayer(x, y))
        //            {
        //                case 0:
        //                    Console.Write(".");
        //                    break;
        //                case 1:
        //                    Console.Write("X");
        //                    break;
        //                case 2:
        //                    Console.Write("O");
        //                    break;
        //                default:
        //                    Console.Write("#");
        //                    break;
        //            }
        //        }
        //        Console.WriteLine();
        //    }
        //    Console.ReadLine();
        //}

        internal int GetPlayer(long x, long y)
        {
            int rv = 0; // Empty square
            foreach (Piece p in pieces)
            {
                if (x == p.x && y == p.y)
                {
                    rv = p.playerNumber;
                }
            }
            return rv;
        }

        internal bool FiveInARow()
        {
            bool rv = false;
            long[] dx = { 0, 1, 1, 1, 0, -1, -1, -1 }, dy = { -1, -1, 0, 1, 1, 1, 0, -1 };
            foreach (Piece p in pieces)
            {
                for (int d = 0; d < 8 && !rv; d++)
                {
                    for (long l = 1; l < 5 && GetPlayer(p.x + dx[d] * l, p.y + dy[d] * l) == p.playerNumber; l++)
                    {
                        if (l == 4) rv = true;
                    }
                }
            }
            return rv;
        }
    }
}
