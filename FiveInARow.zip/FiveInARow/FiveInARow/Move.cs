﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FiveInARow
{
    internal class Move
    {
        internal long x;
        internal long y;
        internal long score;
        internal int rnd;
    }
}
