﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FiveInARow
{
    class Piece
    {
        internal int playerNumber;
        internal long x;
        internal long y;

        public Piece(long initX, long initY, int initPlayerNumber)
        {
            x = initX;
            y = initY;
            playerNumber = initPlayerNumber;
        }
    }
}
