﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace FiveInARow
{
    public partial class Form1 : Form
    {        
        internal static bool tickInProgress = false;
        internal static Rules rules;
        internal int width, height; // Dimensions of last paint, used for mouse input and correct placements of pieces
        internal int zoom=20;
        // DEBUG for mouse input
        //internal int debugMouseX, debugMouseY, debugPosX, debugPosY;

        public Form1()
        {
            InitializeComponent();
            SetDoubleBuffered(panel);
            InitializeForm();            
        }

        /// <summary>
        /// SetDoubleBuffered
        /// Makes the window update without flickering - .NET doublebuffer
        /// </summary>
        /// <param name="c"></param>
        // FROM: http://stackoverflow.com/questions/76993/how-to-double-buffer-net-controls-on-a-form
        public static void SetDoubleBuffered(System.Windows.Forms.Control c)
        {
            //Taxes: Remote Desktop Connection and painting
            //http://blogs.msdn.com/oldnewthing/archive/2006/01/03/508694.aspx
            if (System.Windows.Forms.SystemInformation.TerminalServerSession)
                return;

            System.Reflection.PropertyInfo aProp =
                  typeof(System.Windows.Forms.Control).GetProperty(
                        "DoubleBuffered",
                        System.Reflection.BindingFlags.NonPublic |
                        System.Reflection.BindingFlags.Instance);

            aProp.SetValue(c, true, null);
        }

        private void InitializeForm()
        {
            timer.Enabled = true;
            //if (this.FormBorderStyle != FormBorderStyle.None)
            //{
            //    this.FormBorderStyle = FormBorderStyle.None;
            //    if (this.WindowState == FormWindowState.Maximized) this.WindowState = FormWindowState.Normal;
            //    this.WindowState = FormWindowState.Maximized;
            //}
            rules = new Rules();
            rules.pieces.Clear();
            rules.pieces.Add(new Piece(0, 0, rules.tomove));
            rules.tomove = 2;
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            if (tickInProgress == false)
            {
                tickInProgress = true;

                if (!rules.FiveInARow())
                {
                    if (rules.tomove == 1) // Computer plays red X
                    {
                        AI.AIMakeMove(rules, rules.tomove);
                        rules.tomove = (rules.tomove)%2 + 1;
                        panel.Refresh();
                    }
                }
                else
                {                    
                    Thread.Sleep(1000);
                    rules.pieces.Clear();                   
                    rules.pieces.Add(new Piece(0, 0, rules.tomove));
                    rules.tomove = (rules.tomove) % 2 + 1;
                    panel.Refresh();
                }
            }
            tickInProgress = false;
        }

        private void panel_Paint(object sender, PaintEventArgs e)
        {
            Bitmap img = new Bitmap(e.ClipRectangle.Width, e.ClipRectangle.Height);
            width = (int)(Math.Round(e.ClipRectangle.Width / (2.0 * zoom))) * 2 * zoom + 2 * zoom;
            height = (int)(Math.Round(e.ClipRectangle.Height / (2.0 * zoom))) * 2 * zoom + 2 * zoom;
            
            using (Graphics g = Graphics.FromImage(img))
            {
                g.FillRectangle(Brushes.White, 0, 0, e.ClipRectangle.Width, e.ClipRectangle.Height);
                for (int x = 0; x < e.ClipRectangle.Width; x += zoom)
                {
                    g.DrawLine(Pens.Black, x, 0, x, e.ClipRectangle.Height);
                }
                for (int y = 0; y < e.ClipRectangle.Height; y += zoom)
                {
                    g.DrawLine(Pens.Black, 0, y, e.ClipRectangle.Width, y);
                }

                foreach (Piece p in rules.pieces)
                {
                    if (p.playerNumber == 1)
                    {
                        g.DrawLine(Pens.Red, width / 2 + p.x * zoom + 1, height / 2 + p.y * zoom + 1, width / 2 + p.x * zoom + zoom - 1, height / 2 + p.y * zoom + zoom - 1);
                        g.DrawLine(Pens.Red, width / 2 + p.x * zoom + 1, height / 2 + p.y * zoom + zoom - 1, width / 2 + p.x * zoom + zoom - 1, height / 2 + p.y * zoom + 1);
                    }
                    else
                    {
                        g.DrawArc(Pens.Blue, width / 2 + p.x * zoom + 1, height / 2 + p.y * zoom + 1, zoom-2, zoom-2, 0, 360);                        
                    }
                }
                // DEBUG for mouse input
                //g.FillRectangle(Brushes.White,0,0,300,100);
                //g.DrawString("MouseX: " + debugMouseX, SystemFonts.DefaultFont, Brushes.Red, 10, 10);
                //g.DrawString("MouseY: " + debugMouseY, SystemFonts.DefaultFont, Brushes.Red, 10, 30);
                //g.DrawString("Pos X : " + debugPosX, SystemFonts.DefaultFont, Brushes.Red, 10, 50);
                //g.DrawString("Pos Y : " + debugPosY, SystemFonts.DefaultFont, Brushes.Red, 10, 70);
            }
            e.Graphics.DrawImage(img, 0, 0);
            img.Dispose();
        }

        private void panel_MouseClick(object sender, MouseEventArgs e)
        {
            // Player made a move - blue O
            int posX=0;
            int posY=0;

            for (int x = 0; x < width; x += zoom)
            {
                for (int y = 0; y < height; y += zoom)
                {
                    if (e.X > x && e.X < (x + zoom) && e.Y > y && e.Y < (y + zoom))
                    {
                        posX = (x - width / 2) / zoom;
                        posY = (y - height / 2) / zoom;
                    }
                }
            }
            //debugMouseX = e.X;
            //debugMouseY = e.Y;
            //debugPosX = posX;
            //debugPosY = posY;
            if (!rules.pieces.Any(o => o.x == posX && o.y == posY))
            {
                rules.pieces.Add(new Piece(posX, posY, rules.tomove));
                rules.tomove = (rules.tomove)%2 + 1;
                panel.Refresh();
            }
        }

        private void panel_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (this.FormBorderStyle == FormBorderStyle.None)
            {
                this.FormBorderStyle = FormBorderStyle.Sizable;
                this.WindowState = FormWindowState.Normal;
            }
            else
            {
                this.FormBorderStyle = FormBorderStyle.None;
                if (this.WindowState == FormWindowState.Maximized) this.WindowState = FormWindowState.Normal;
                this.WindowState = FormWindowState.Maximized;
            }
        }

        private void panel_Resize(object sender, EventArgs e)
        {
            panel.Refresh();
        }
    }
}
